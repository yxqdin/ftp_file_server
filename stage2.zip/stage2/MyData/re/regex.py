import re

s="Levi:1994,Sunny:1993"
pattern=r"\w+:\d+"

# re模块调用
l=re.findall(pattern,s)
print(l)

s="Levi:1994,Sunny:1993"
pattern=r"(\w+):(\d+)"

# re模块调用
l=re.findall(pattern,s)
print(l)

# compile对象调用
regex=re.compile(pattern)
l=regex.findall(s)
print(l)
l=regex.findall(s,0,12)
print(l)

print("============================================")

#切割字符串
s="hello world how are you L-body"
l=re.split(r'[^\w]+',s)
print(l)
l=re.split(r'\W+',s)
print(l)

#替换字符串
s="时间: 2019/10/12"
ns=re.sub(r'/','-',s,1)
print(ns)
ns=re.subn(r'/','-',s,1)
print(ns)
