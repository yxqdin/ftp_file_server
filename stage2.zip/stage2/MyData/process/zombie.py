#僵尸进程,子进程先于父进程结束

import os

child_pid = os.fork()
if child_pid < 0:
    print("error")
elif child_pid == 0:
    print("child process")
    print("child pid:", os.getpid())
    print("parent pid", os.getppid())
else:
    while True:
        pass