#用信号模块的方法处理僵尸

import os
import signal

#处理子进程退出(这种方法是非阻塞的)
signal.signal(signal.SIGCHLD,signal.SIG_IGN)

pid=os.fork()

if pid <0:
    pass
elif pid==0:
    print("child pid:",os.getpid())
else:
    while True:
        pass