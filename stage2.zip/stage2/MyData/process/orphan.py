#孤儿进程,父进程先于子进程结束

import os
from time import sleep

child_pid = os.fork()
if child_pid < 0:
    print("error")
elif child_pid == 0:
    sleep(2)
    print("child process")
    print("child pid:", os.getpid())
    print("parent pid", os.getppid())
else:
    print("parent process")
    print("parent pid:", os.getpid())
    print("child pid", child_pid)