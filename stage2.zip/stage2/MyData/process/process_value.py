#创建共享内存

from multiprocessing import Value,Process
from time import sleep
from random import randint

#创建共享内存
money=Value('i',5000)

#操作共享内存
def man():
    for i in range(30):
        sleep(0.2)
        money.value+=randint(1,1000)

def girl():
    for i in range(30):
        sleep(0.15)
        money.value-=randint(100,800)

m=Process(target=man)
g=Process(target=girl)

m.start()
g.start()

m.join()
g.join()

#获取共享内存的值
print("一月余额:%d"%money.value)
