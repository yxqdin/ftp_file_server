#处理僵尸

import os
from time import sleep

child_pid = os.fork()
if child_pid < 0:
    print("error")
elif child_pid == 0:
    print("child process")
    print("child pid:", os.getpid())
    print("parent pid", os.getppid())
    os._exit(5)
else:
    # zombie_pid,status=os.wait()#等待处理僵尸
    sleep(1)
    zombie_pid,status=os.waitpid(-1,os.WNOHANG)#非阻塞模式
    print("zombie pid:",zombie_pid)
    print("status:",status)
    print("status:",os.WEXITSTATUS(status))
    while True:
        pass