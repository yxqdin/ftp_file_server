#将子进程封装为函数
#multiprocessing示例
import multiprocessing as mp
from  time import  sleep

#子进程函数
def fun():
    print("子进程开始执行")
    sleep(3)
    print("子进程执行完毕")

#创建进程对象
p=mp.Process(target=fun)

#启动进程(调用start时启动子进程)
p.start()

#父进程
print("父进程开始执行")
sleep(2)
print("父进程执行完毕")

#回收进程
p.join()
