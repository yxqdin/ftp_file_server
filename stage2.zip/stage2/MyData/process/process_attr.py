#进程属性
from multiprocessing import Process
from time import sleep, ctime


def tm():
    for i in range(3):
        sleep(2)
        print(ctime())


p = Process(target=tm, name='蔡徐坤')
p.daemon = True  # 子进程随父进程退出而退出
p.start()
print("name:", p.name)  # 进程名称
print("pid", p.pid)  # 进程id
print("is alive", p.is_alive())  # 进程是否在生命周期
