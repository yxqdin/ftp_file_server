import os
from time import sleep
print("===============================")
a=30000

pid =os.fork()

if pid<0:
    print("Error")
elif pid == 0:
    print("Child process")
    print("a=%d"%a)
    print(id(a))
    a=10000
    print(id(a))
else:
    sleep(1)
    print("Parent process")
    print(id(a))
    print("a=%d"%a)
    a=20000
    print(id(a))
print("All a=%d"%a)
print(id(a))