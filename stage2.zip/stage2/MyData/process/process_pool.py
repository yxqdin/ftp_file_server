#进程池

from multiprocessing import Process,Pool
from time import sleep, ctime

#进程池事件
def worker(msg):
    sleep(2)
    print(msg)
    return ctime()

#创建进程池(系统几个内核分配几个进程,也可以在括号输入整数指定数量)
p=Pool()
l=[]
#向进程池添加事件
for i in range(20):
    msg="事件 %d" %i
    r=p.apply_async(func=worker,args=(msg,))
    l.append(r)

#关闭进程池(不允许添加事件)
p.close()

#回收进程池
p.join()

#获取进程返回值
for i in l:
    print(i.get())