#将子进程封装为函数(带参数)
from multiprocessing import Process
from  time import  sleep
import os

#带参数的进程函数
def worker(sec,name):
    for i in range(3):
        sleep(sec)
        print("全民制作人们大家好,我是练习时长两年半的%s"%name)
        print("我会唱跳rap篮球music")

# p=Process(target=worker,args=(2,"蔡徐坤"))
p=Process(target=worker,kwargs={"name":"蔡徐坤","sec":2})
p.start()
p.join()