#进程间通信
#管道通信

from multiprocessing import  Process,Pipe
import  os,time

#创建管道
# fd1,fd2=Pipe()#双向管道
fd1,fd2=Pipe(False)#单向管道fd1只能读,fd2只能写

def fun(name,second):
    time.sleep(second)
    #向管道写入内容
    fd2.send({name:os.getpid()})

jobs=[]

for i in range(5):
    p=Process(target=fun,args=(i,i))
    jobs.append(p)
    p.start()

for i in range(5):
    #读取管道
    data=fd1.recv()
    print(data)

for i in jobs:
    i.join()
