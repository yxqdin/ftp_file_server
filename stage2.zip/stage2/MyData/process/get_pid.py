import os

child_pid = os.fork()
if child_pid < 0:
    print("error")
elif child_pid == 0:
    print("child process")
    print("child pid:", os.getpid())
    print("parent pid", os.getppid())
else:
    print("parent process")
    print("parent pid:", os.getpid())
    print("child pid", child_pid)
