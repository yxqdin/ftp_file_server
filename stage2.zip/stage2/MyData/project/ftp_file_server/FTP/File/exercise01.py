from socket import *
sockfd=socket()
sockfd_adrr=('172.40.71.207',8888)
sockfd.connect(sockfd_adrr)
data=input("发送信息:")
sockfd.send(data.encode())
data01=sockfd.recv(1024)
print("收到信息：",data01.decode())
sockfd.close()