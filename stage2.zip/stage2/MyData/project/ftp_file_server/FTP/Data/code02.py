"""
    函数
"""

print("需要显示的内容")

qtx = input("需要显示的内容")

print(qtx)