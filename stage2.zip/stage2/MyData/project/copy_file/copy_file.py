from multiprocessing import  Process
import os

filename="./timg.jpeg"
#获取图片大小
size=os.path.getsize(filename)

#复制上半部分
def top():
    fr=open(filename,'rb')
    n=size//2
    fw=open("top.jpeg",'wb')
    fw.write(fr.read(n))
    fr.close()
    fw.close()

#复制下半部分
def bot():
    fr=open(filename,'rb')
    fw=open("bot.jpeg",'wb')
    fr.seek(size//2,0)
    while True:
        data=fr.read(1024)
        if not data:
            break
        fw.write(data)
    fr.close()
    fw.close()

t=Process(target=top)
b=Process(target=bot)
t.start()
b.start()
t.join()
b.join()