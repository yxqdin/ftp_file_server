class Sort:
    def __init__(self, list_):
        self.list_ = list_

    def bubble(self):
        for i in range(len(self.list_) - 1):
            for j in range(len(self.list_) - 1 - i):
                if self.list_[j] > self.list_[j + 1]:
                    self.list_[j], self.list_[j + 1] = self.list_[j + 1], self.list_[j]

    def select(self):
        for i in range(len(self.list_) - 1):
            min = i
            for j in range(i + 1, len(self.list_)):
                if self.list_[min] > self.list_[j]:
                    min = j
            if i != min:
                self.list_[i], self.list_[min] = self.list_[min], self.list_[i]

    def insert(self):
        for i in range(1, len(self.list_)):
            x = self.list_[i]
            j = i
            while j > 0 and self.list_[j - 1] > x:
                self.list_[j] = self.list_[j - 1]
                j -= 1
            self.list_[j] = x

    # 一轮交换
    def sub_sort(self, low, high):
        key_num = self.list_[low]  # 基准数字
        while low < high:
            # 后面的小数向前甩
            while low < high and self.list_[high] >= key_num:
                high -= 1
            self.list_[low] = self.list_[high]
            # 前面的大数向后甩
            while low < high and self.list_[low] < key_num:
                low += 1
            self.list_[high] = self.list_[low]
        self.list_[low] = key_num
        return low

    # 快排函数
    def quick(self, low, high):
        # low列表开头元素索引
        # high列表结尾元素索引
        if low < high:
            key = self.sub_sort(low, high)
            self.quick(low, key - 1)
            self.quick(key + 1, high)


if __name__ == "__main__":
    l = [4, 1, 2, 6, 7, 3, 9, 8, 2, 8]
    sr = Sort(l)
    sr.quick(0, len(l) - 1)
    print(sr.list_)
