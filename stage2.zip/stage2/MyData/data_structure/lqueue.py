class QueueError(Exception):
    pass

class Node(object):
    def __init__(self, val, next=None):
        self.val = val  # 有用数据
        self.next = next

class LQueue:

    def __init__(self):
        self.front =self.rear = Node(None)

    def is_empty(self):
        return self.front==self.rear

    def enqueue(self,val):
        self.rear.next=Node(val)
        self.rear=self.rear.next

    def dequeue(self):
        if self.is_empty():
            raise QueueError("Queue is empty")
        self.front=self.front.next
        return self.front.val

    def clear(self):
        self.front=self.rear

if __name__ == "__main__":
    lq= LQueue()
    print(lq.is_empty())
    lq.enqueue(10)
    lq.enqueue(20)
    lq.enqueue(30)
    while not lq.is_empty():
        print(lq.dequeue())