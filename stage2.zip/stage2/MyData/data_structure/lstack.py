class StackError(Exception):
    pass


class Node(object):
    def __init__(self, val, next=None):
        self.val = val  # 有用数据
        self.next = next


class LStack:

    def __init__(self):
        self._top = None

    def is_empty(self):
        return self._top is None

    def push(self, val):
        self._top = Node(val, self._top)

    def pop(self):
        if self._top is None:
            raise StackError("stack is empty")
        p = self._top
        self._top = p.next
        return p.val

    def top(self):
        if self._top is None:
            raise StackError("stack is empty")
        return self._top.val

if __name__ == "__main__":
    st = LStack()
    st.push(10)
    st.push(20)
    print(st.top())
    st.push(30)
    while st.is_empty()==False:
        print(st.pop())