"""
单链表学习程序
重点程序
"""


# 创建节点类
class Node(object):
    def __init__(self, val, next=None):
        self.val = val  # 有用数据
        self.next = next


# 链表的操作
class LinkList(object):

    def __init__(self):
        self.head = Node(None)

    def init_list(self, data):
        p = self.head  # 可移动变量p
        for i in data:
            p.next = Node(i)
            p = p.next

    def show(self):
        p = self.head.next
        while p != None:
            print(p.val, end=' ')
            p = p.next
        print()

    def append(self, val):
        p = self.head
        while p.next != None:
            p = p.next
        p.next = Node(val)

    def get_length(self):
        count = 0
        p = self.head
        while p.next != None:
            count += 1
            p = p.next
        return count

    def is_empty(self):
        if self.get_length() == 0:
            return True
        return False

    def clear(self):
        self.__init__()

    def get_item(self, n):
        if n<1 or n>self.get_length():
            raise IndexError("list index out of range")
        p = self.head
        for i in range(n):
            p = p.next
        return p.val

    def insert(self, n, val):
        p = self.head
        if n<1 or n>self.get_length():
            raise IndexError("list index out of range")
        for i in range(n - 1):
            p = p.next
        p.next = Node(val, p.next)

    def update(self, n, val):
        p = self.head
        if n<1 or n>self.get_length():
            raise IndexError("list index out of range")
        for i in range(n):
            p = p.next
        p.val = val

    def remove(self, val):
        p = self.head
        if self.is_empty():
            print("链表为空,无需删除")
            return
        while p.next.val != val:
            p = p.next
            if p.next == None:
                print("要删除的目标不存在")
                return
        p.next = p.next.next
        print("第一个值为",val,"的节点删除成功")

    def delete(self,n):
        p = self.head
        if self.is_empty():
            print("链表为空,无需删除")
            return
        if n<1 or n>self.get_length():
            raise IndexError("list index out of range")
        for i in range(n-1):
            p = p.next
        p.next = p.next.next
        print("第",n, "个节点删除成功")


if __name__ == "__main__":
    # 创建链表对象
    link = LinkList()

    # 初始数据
    l = [35, 75, 63, 23, 47]

    link.init_list(l)
    link.show()

    # link.append(6)
    # link.show()

    # link.insert(7, 7)
    # link.show()

    # link.update(7, 100)
    # link.show()

    # n = 1
    # print("第", n, "个节点的值为:", link.get_item(n))
    # link.show()

    # link.remove(4)
    # link.show()

    # link.delete(5)
    # link.show()

    # print("链表长度:", link.get_length())
    # link.show()

    # print("链表是否为空:", link.is_empty())
    # link.show()

    # link.clear()
    # link.show()

    # print("链表是否为空:", link.is_empty())
    # link.show()
