from squeue import SQueue

class TreeNode:
    def __init__(self,data=None,left=None,right=None):
        self.data=data
        self.left=left
        self.right=right

class Bitree:

    def __init__(self,root=None):
        self.root = root

    def is_empty(self):
        return self.root==None

    def pre_order(self,node):
        if node == None:
            return
        print(node.data,end=' ')
        self.pre_order(node.left)
        self.pre_order(node.right)

    def in_order(self,node):
        if node == None:
            return
        self.in_order(node.left)
        print(node.data,end=' ')
        self.in_order(node.right)

    def post_order(self,node):
        if node == None:
            return
        self.post_order(node.left)
        self.post_order(node.right)
        print(node.data,end=' ')

    def level_order(self,node):
        qu=SQueue()
        qu.enqueue(node)
        while qu.is_empty()==False:
            node = qu.dequeue()
            print(node.data,end=' ')
            if node.left!=None:
                qu.enqueue(node.left)
            if node.right!=None:
                qu.enqueue(node.right)

if __name__ == "__main__":
    b=TreeNode('B')
    f=TreeNode('F')
    g=TreeNode('G')
    d=TreeNode('D',f,g)
    i=TreeNode('I')
    h=TreeNode('H')
    e=TreeNode('E',h,i)
    c=TreeNode('C',d,e)
    a=TreeNode('A',b,c)
    bt=Bitree(a)
    bt.pre_order(bt.root)
    print()
    bt.in_order(bt.root)
    print()
    bt.post_order(bt.root)
    print()
    bt.level_order(bt.root)




