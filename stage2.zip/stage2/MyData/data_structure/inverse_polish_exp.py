from data_structure.lstack import LStack
def num_oper(exp):
    numbers = "0123456789."
    operators = "+-"
    st = LStack()
    str_num=""
    exp_len=len(exp)
    for i in range(exp_len):
        if exp[i] in numbers:
            str_num+=exp[i]
        if exp[i]==' ' and exp[i-1] in numbers:
            st.push(eval(str_num))
            str_num=""
        if exp[i] in operators:
            str_num01=str(st.pop())
            str_num02=str(st.pop())
            st.push(eval(str_num02+exp[i]+str_num01))
        if exp[i]=='p':
            return st.pop()
print("请输入逆波兰表达式:")
print(num_oper(input("")))

