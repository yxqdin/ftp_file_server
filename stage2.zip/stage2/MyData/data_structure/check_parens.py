from sstack import SStack

st = SStack()
# list01 = "1212{aas(fdsf)fdfsf[wewe(ssss)fff(4f3s)gfdg]4342}sfsdf"
# for i in list01:
#     if i == "(":
#         st.push(1)
#     if i == "[":
#         st.push(2)
#     if i == "{":
#         st.push(3)
#     if i == ")" and st.top() == 1:
#         st.pop()
#     if i == "]" and st.top() == 2:
#         st.pop()
#     if i == "}" and st.top() == 3:
#         st.pop()
# if st.is_empty():
#     print("括号匹配正确")
# else:
#     print("括号匹配错误")

parens="()[]{}"
left_parens="([{"
opposite={")":"(","]":"[","}":"{"}

text = "1212{aas(fdsf)fdfsf[wewe(ssss)fff(4f3s)gfdg]4342}sfsdf"

def parent(text):
    i,text_len=0,len(text)
    while True:
        #逐个遍历字符,如果没到结尾并且不是括号就向后遍历
        while i< text_len and text[i] not in parens:
            i+=1
        if i>=text_len:
            return
        else:
            yield text[i],i
            i+=1


for pr,i in parent(text):
    if pr in left_parens:
        st.push((pr,i))
    elif st.is_empty() or st.pop()[0]!=opposite[pr]:
        print("Unmatching is found at %d for %s"%(i,pr))
        break
else:
    if st.is_empty():
        print("All parentheses are matched")
    else:
        e=st.pop()
        print("Unmatching is found at %d for %s"%(e[1],e[0]))