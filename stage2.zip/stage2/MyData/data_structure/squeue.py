class QueueError(Exception):
    pass

class SQueue:

    def __init__(self):
        self._elems=[]

    def is_empty(self):
        return self._elems==[]

    def enqueue(self,val):
        self._elems.append(val)

    def dequeue(self):
        if self.is_empty():
            raise QueueError("Queue is empty")
        return self._elems.pop(0)

if __name__ == "__main__":
    sq=SQueue()
    print(sq.is_empty())
    sq.enqueue(10)
    sq.enqueue(20)
    sq.enqueue(30)
    while not sq.is_empty():
        print(sq.dequeue())