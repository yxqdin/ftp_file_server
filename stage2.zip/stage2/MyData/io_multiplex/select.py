"""
select 函数讲解
多个内核监控多个io,哪个就绪执行哪个
"""
from socket import *
from select import select

# 做几个io用作监控
s=socket()
s.bind(('0.0.0.0',8888))
s.listen(3)

fd=open('log.txt','a+')

print("开始提交监控的io")
rs,ws,xs=select([fd],[fd],[])#最后一个数字超时等待时间

print("rs:",rs)
print("ws:",ws)
print("xs:",xs)
