"""
套接字非阻塞示例
"""

from socket import *
from time import sleep,ctime
f=open('log.txt','w')
#tcp套接字
sockfd=socket()
sockfd.bind(('127.0.0.1',8888))
sockfd.listen(3)

# 设置套接字为非阻塞
# sockfd.setblocking(False)

# 超时检测
sockfd.settimeout(3)

#以上两种方法选择一种

while True:
    print("waiting for connect...")
    try:
        connfd,addr=sockfd.accept()
    except (BlockingIOError, timeout) as e:
        #没有客户端连接则每隔2s写入一条日志,不用死等
        sleep(2)
        f.write("%s:%s\n"%(ctime(),e))
        f.flush()
    else:
        data=connfd.recv(1024).decode()
        print(data)
