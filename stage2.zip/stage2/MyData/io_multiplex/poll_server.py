"""
io多路复用poll实现多客户端通信
重点代码
"""

from socket import *
from select import *

# 设置套接字为关注的io
s = socket()
s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
s.bind(('0.0.0.0', 8888))
s.listen(5)

# 创建poll
p = poll()

# 建立查找字典{fileno:io_obj}
fdmap = {s.fileno(): s}

# 设置关注io
p.register(s, POLLIN | POLLERR)

# 循环监控io事件发生
while True:
    events = p.poll()  # 阻塞等待io发生
    for fd, event in events:
        if fd == s.fileno():
            c, addr = fdmap[fd].accept()
            print("connect from", addr)
            # 添加新的关注事件
            p.register(c, POLLIN | POLLHUP)
            fdmap[c.fileno()] = c
        # elif event & POLLHUP:
        #     print("客户端退出")
        #     p.unregister(fd)  # 取消关注
        #     fdmap[fd].close()
        #     del fdmap[fd]  # 从字典删除
        elif event & POLLIN:  # 客户端发消息
            data = fdmap[fd].recv(1024)
            if not data:  # 客户端断开
                p.unregister(fd)  # 取消关注
                fdmap[fd].close()
                del fdmap[fd]  # 从字典删除
                continue
            print(data.decode())
            fdmap[fd].send(b'OK')
