"""
io多路复用select实现多客户端通信
重点代码
"""

from socket import *
from select import select

# 设置套接字为关注的io
s = socket()
s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
s.bind(('0.0.0.0', 8888))
s.listen(5)

# 设置关注的io
rlist = [s]
wlist = []
xlist = []

while True:
    # 监控io的发生
    rs, ws, xs = select(rlist, wlist, xlist)
    # 遍历三个返回值列表,判断哪个io发生
    for r in rs:
        # 如果是套接字就绪则处理连接
        if r is s:
            c, addr = r.accept()
            print("connect from ", addr)
            rlist.append(c)  # 加入新的关注io
        else:
            data = r.recv(1024)
            if not data:
                rlist.remove(r)
                r.close()
                continue
            print(data)
            # r.send(b'OK')
            # 希望我们主动处理这个io
            wlist.append(r)
    for w in ws:
        w.send(b'OK,thanks')
        wlist.remove(w)
    for x in xs:
        pass
