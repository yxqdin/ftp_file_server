"""
io多路复用epoll实现多客户端通信
重点代码
"""

from socket import *
from select import *

# 设置套接字为关注的io
s = socket()
s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
s.bind(('0.0.0.0', 8888))
s.listen(5)

# 创建epoll
ep = epoll()

# 建立查找字典{fileno:io_obj}
fdmap = {s.fileno(): s}

# 设置关注io
ep.register(s, EPOLLIN | EPOLLERR)

# 循环监控io事件发生
while True:
    events = ep.poll()  # 阻塞等待io发生
    print(events)
    for fd, event in events:
        if fd == s.fileno():
            c, addr = fdmap[fd].accept()
            print("connect from", addr)
            # 添加新的关注事件
            ep.register(c, EPOLLIN | EPOLLHUP | EPOLLET)
            # EPOLLET 边缘触发,不处理则不循环发送,处理时可以把之前的一起接收
            fdmap[c.fileno()] = c
        # elif event & EPOLLHUP:
        #     print("客户端退出")
        #     p.unregister(fd)  # 取消关注
        #     fdmap[fd].close()
        #     del fdmap[fd]  # 从字典删除
        elif event & EPOLLIN:  # 客户端发消息
            data = fdmap[fd].recv(1024)
            if not data:  # 客户端断开
                ep.unregister(fd)  # 取消关注
                fdmap[fd].close()
                del fdmap[fd]  # 从字典删除
                continue
            print(data.decode())
            fdmap[fd].send(b'OK')
