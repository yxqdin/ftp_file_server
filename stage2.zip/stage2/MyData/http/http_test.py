from socket import *

s=socket()
s.bind(('0.0.0.0',8001))
s.listen(3)
c,addr=s.accept()
print("Connect from",addr)
data=c.recv(4096)
print(data)
#http响应格式
data="""HTTP/1.1 200 OK
Content-Type:text/html

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>首页</title>
</head>
<body>
    <h1>蔡徐坤欢迎你</h1>
    <p>鸡你太美</p>
</body>
</html>
"""
c.send(data.encode())
c.close()
s.close()
