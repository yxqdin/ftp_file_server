# 客户端用TCP协议传输图片到服务端
from socket import *

# 创建套接字
sockfd = socket(AF_INET, SOCK_STREAM)
sockfd.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
# 绑定地址
sockfd.bind(('172.40.71.175', 9527))
# 设置监听
sockfd.listen(5)
# 等待处理客户端连接
print("Waiting for connect...")
connfd, addr = sockfd.accept()
fw = open("/home/tarena/uhdsuh.jpg", 'wb')
# 收发消息
while True:
    data = connfd.recv(1024)
    # 如果客户端断开,则立刻接收到空,跳出
    if not data:
        break
    fw.write(data)
# 关闭套接字
fw.close()
connfd.close()
sockfd.close()
