#客户端输入一个学生信息,udp协议,服务端写入文件,每个信息占一行
from socket import *
from struct import *
sockfd = socket(AF_INET,SOCK_DGRAM)
sockfd.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
server_addr = ('172.40.71.175', 8888)
sockfd.connect(server_addr)
#规定数据格式
st=Struct('i3sif')
while True:
    print("==============================")
    id = int(input("请输入编号:"))
    if id==0:
        break
    name = input("输入学生姓名:").encode()
    age = int(input("输入学生年龄:"))
    score = float(input("请输入学生成绩:"))
    data=st.pack(id,name,age,score)
    sockfd.sendto(data,server_addr)
sockfd.close()