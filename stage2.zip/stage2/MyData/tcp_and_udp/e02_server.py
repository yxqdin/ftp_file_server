#客户端输入一个学生信息,udp协议,服务端写入文件,每个信息占一行
from socket import *
from struct import *

sockfd = socket(AF_INET, SOCK_DGRAM)
sockfd.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
sockfd.bind(('172.40.71.175', 8888))

st=Struct('i3sif')
fa = open("/home/tarena/student.txt", 'a')

while True:
    data,addr = sockfd.recvfrom(1024)
    data=st.unpack(data)
    info="%d\t%s\t%d\t%.2f\n"%(data[0],data[1].decode(),data[2],data[3])
    fa.write(info)
    fa.flush()
# 关闭套接字
fa.close()
sockfd.close()