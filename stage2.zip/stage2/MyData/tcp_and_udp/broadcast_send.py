#广播发送

from socket import *
from time import sleep

#广播地址
dest=('172.40.71.255',8888)

s=socket(AF_INET,SOCK_DGRAM)

s.setsockopt(SOL_SOCKET,SO_BROADCAST,1)

data="""
**********************
全民制作人们大家好
我是练习时长两年半的cxk
喜欢唱跳rap篮球
music
**********************
"""
while True:
    sleep(0)
    s.sendto(data.encode(),dest)
