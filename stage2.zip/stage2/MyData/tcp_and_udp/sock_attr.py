from socket import *
s=socket()
#设置套接字端口立即重用
s.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)

print("地址类型:",s.family)
print("套接字类型:",s.type)
print("绑定地址:",s.getsockname())
print("描述符:",s.fileno())
print("客户端地址:",s.getpeername())
