# 客户端用TCP协议传输图片到服务端
from socket import *

# 创建tcp套接字
sockfd = socket()
# 发起连接
server_addr = ('172.40.71.XXX', 9527)
sockfd.connect(server_addr)
fr = open("/home/tarena/stage2/冒泡排序.gif", 'rb')
# 收发消息
while True:
    data = fr.read(1024)
    # 如果输入为空,跳出
    if not data:
        break
    sockfd.send(data)
# 关闭
fr.close()
sockfd.close()
