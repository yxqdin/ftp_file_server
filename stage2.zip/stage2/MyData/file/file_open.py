#打开文件
try:
    fd=open("/home/tarena/test",'r')
except FileNotFoundError as e:
    print(e)
else:
    print("文件打开成功")
#读写文件



#关闭文件
fd.close()

