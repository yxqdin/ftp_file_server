#打开文件
try:
    fd=open("/home/tarena/test",'a+')
except FileNotFoundError as e:
    print(e)
else:
    print("文件打开成功")

fd.write('666777\n')

# 关闭文件
fd.close()
