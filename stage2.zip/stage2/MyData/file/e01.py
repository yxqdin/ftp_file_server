# 终端输入路径文件,将文件复制到当前目录下,重命名,要求适用所有文件格式
# str_file=input("输入文件路径:")
# fd01 = open(str_file, 'rb')
# fd02 = open('new_file','wb')
# fd02.write(fd01.read())
# fd01.close()
# fd02.close()

# str_file=input("输入文件路径:")
# with open(str_file, 'rb') as f01:
#     data=f01.read()
#     with open('new_file','wb') as f02:
#         f02.write(data)

str_file = input("输入文件路径:")
try:
    fr = open(str_file, 'rb')
except FileNotFoundError as e:
    print(e)
else:
    fw = open('mew_file', 'wb')
    while True:
        data = fr.read(1024)
        if not data:
            break
        fw.write(data)
