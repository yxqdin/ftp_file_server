#打开文件
try:
    fd=open("/home/tarena/test",'r')
except FileNotFoundError as e:
    print(e)
else:
    print("文件打开成功")
#读写文件
# while True:
#     data=fd.read(3)
#     if not data:
#         break
#     print("读到的内容:",data)
# while True:
#     data=fd.readline(3)
#     if not data:
#         break
#     print("读到的内容:",data)
#     print()
# while True:
#     data=fd.readlines(3)
#     if not data:
#         break
#     print("读到的内容:",data)
#     print()

for line in fd:
    print("每行内容:",line)
#关闭文件
fd.close()