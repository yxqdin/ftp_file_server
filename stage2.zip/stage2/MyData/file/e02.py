#每隔1秒在文件写入时间,要求重启程序,序号连续

import time
try:
    fr=open('new_file','r')
    list_data=fr.readlines()
    if not list_data:
        array=0
        with open('new_file','w') as fw:
            while True:
                array+=1
                fw.write(time.strftime(str(array)+'.\t%Y-%m-%d\t%H:%M:%S\n'))
                fw.flush()
                time.sleep(1)
    else:
        array=int(list_data[-1].split('.')[0])
        with open('new_file','a') as fa:
            while True:
                array+=1
                fa.write(time.strftime(str(array)+'.\t%Y-%m-%d\t%H:%M:%S\n'))
                fa.flush()
                time.sleep(1)
except FileNotFoundError as e:
    print(e)
    array = 0
    with open('new_file', 'w') as fw:
        while True:
            array += 1
            fw.write(time.strftime(str(array) + '.\t%Y-%m-%d\t%H:%M:%S\n'))
            fw.flush()
            time.sleep(1)

