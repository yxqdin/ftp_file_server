# fd = open('/home/tarena/test', 'w', 0)  # 无缓冲(写一个存一次)
# fd = open('/home/tarena/test','w', 1)  # 行缓冲(写一行存一次)
# fd = open('/home/tarena/test','w', 2)  # 1以上指定缓冲区大小
fd = open('/home/tarena/test','w')  # 系统默认缓冲区大小
while True:
    s = input('>>')
    fd.write(s)
    fd.flush()#立即刷新缓冲区,将内容写入磁盘

fd.close()#遇到close或程序结束存入磁盘
