fd=open("/home/tarena/test",'r')
print("当前文件偏移量位置:",fd.tell())#0
print(fd.read(2))
print("当前文件偏移量位置:",fd.tell())#2
print(fd.read(2))
fd.seek(0,0)#第一个参数偏移量,第二个参数0开头1当前2结尾
print("当前文件偏移量位置:",fd.tell())#2
print(fd.read(2))
fd.seek(0,1)
print("当前文件偏移量位置:",fd.tell())#2
print(fd.read(2))

fd.close()