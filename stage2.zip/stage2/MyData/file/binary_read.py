fd = open("/home/tarena/test", 'rb')
data=fd.read()
print(data)