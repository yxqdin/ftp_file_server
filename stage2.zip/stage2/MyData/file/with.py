with open("/home/tarena/test",'r') as f:
    data=f.read()
    print(data)