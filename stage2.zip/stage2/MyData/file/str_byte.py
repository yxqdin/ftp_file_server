s=input(">>")
#字符串-->字节串
byte=s.encode()
print("byte:",byte)
#字节串-->字符串
s=byte.decode()
print("str:",s)
#打印字节串ASCII码前加b
print("bytes:",b"hello world")
#通过字节串转换函数转换为字节串
print("int 1:",bytes(5))
print("int 1:",bytes('aaaa',encoding='utf-8'))
print("int 1:",bytes([1,2,3,4]))