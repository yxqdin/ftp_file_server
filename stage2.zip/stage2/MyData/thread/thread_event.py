#线程间通信采用全局变量,但会互相影响,采用Event类中阻塞功能解决
from threading import Thread,Event
from time import sleep

s=None#全局变量用于通信
e=Event()
def yangzirong():
    print("杨子荣前来拜山来")
    global s
    s="天王盖地虎"
    e.set()#共享资源操作完毕

t=Thread(target=yangzirong)
t.start()
print("说对口令就是自己人")
e.wait()#阻塞等待
if s=="天王盖地虎":
    print("宝塔镇河妖")
    print("确认过眼神,你是对的人")
else:
    print("打死他...")