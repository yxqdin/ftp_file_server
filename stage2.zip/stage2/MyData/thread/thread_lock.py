#线程间通信采用全局变量,但会互相影响,采用Lock类中信号量功能解决
from threading import Thread,Lock

a=b=0
l=Lock()
def value():
    while True:
        l.acquire()#上锁
        if a!=b:
            print("a=%d,b=%d"%(a,b))
        l.release()#解锁

t=Thread(target=value)
t.start()
while True:
    l.acquire()#用于有语句块需要连续执行后才能进行别的操作
    a+=1
    b+=1
    l.release()
t.join()

# def value():
#     while True:
#         with l:
#             if a!=b:
#                 print("a=%d,b=%d"%(a,b))
#
# t=Thread(target=value)
# t.start()
# while True:
#     with l:
#         a+=1
#         b+=1
# t.join()