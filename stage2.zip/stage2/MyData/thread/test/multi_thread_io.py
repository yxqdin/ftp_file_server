import threading, time


# io密集型函数
def io():
    write()
    read()


def write():
    f = open('test', 'w')
    for i in range(1500000):
        f.write('hello world\n')
    f.close()


def read():
    f = open('test')
    lines = f.readlines()
    f.close()


t0 = time.time()
jobs=[]
for i in range(10):
    t = threading.Thread(target=io)
    jobs.append(t)
    t.start()
for i in jobs:
    i.join()
t1 = time.time()
print(t1 - t0)  # 3.1328985691070557