# 计算密集型函数
def count(x, y):
    c = 0
    while c < 7000000:
        c += 1
        x += 1
        y += 1


# io密集型函数
def io():
    write()
    read()


def write():
    f = open('test', 'w')
    for i in range(1500000):
        f.write('hello world\n')
    f.close()


def read():
    f = open('test')
    lines = f.readlines()
    f.close()

# 编写程序完成效率测试
# 使用单线程执行计算密集函数10次,记录时间,执行io密集函数10次记录时间
# 使用10个线程分别执行计算密集函数1次记录时间,执行io密集函数1次记录时间
# 使用10个进程分别执行计算密集函数1次记录时间,执行io密集函数1次记录时间
