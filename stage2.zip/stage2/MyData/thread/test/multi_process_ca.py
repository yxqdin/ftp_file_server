import multiprocessing, time


# 计算密集型函数
def count(x, y):
    c = 0
    while c < 7000000:
        c += 1
        x += 1
        y += 1


t0 = time.time()
jobs=[]
for i in range(10):
    p = multiprocessing.Process(target=count, args=(0, 0))
    jobs.append(p)
    p.start()
for i in jobs:
    i.join()
t1 = time.time()
print(t1 - t0)  # 1.6442012786865234