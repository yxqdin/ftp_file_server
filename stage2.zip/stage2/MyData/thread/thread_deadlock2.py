# 死锁示例2
from threading import Thread, RLock  # 重复载入锁,用Lock会阻塞导致死锁
import time

num = 0  # 共享资源
l = RLock()  # 在一个线程内可以对锁进行重复加锁


class MyThread(Thread):
    def fun1(self):
        global num
        with l:  # 上锁
            num -= 1

    def fun2(self):
        global num
        if l.acquire():
            num += 1
            if num > 5:
                self.fun1()
            print(self.name, "num=", num)
            l.release()

    def run(self):
        while True:
            time.sleep(2)
            self.fun2()


jobs = []
for i in range(10):
    t = MyThread(name="Thread-" + str(i))
    jobs.append(t)
    t.start()
for i in jobs:
    i.join()
