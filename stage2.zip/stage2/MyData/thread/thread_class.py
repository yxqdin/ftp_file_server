from threading import Thread

class ThreadClass(Thread):
    def __init__(self,attr):
        self.attr=attr
        super().__init__()
    #多个方法配合实现具体功能
    def f1(self):
        print("步骤一")
    def f2(self):
        print("步骤二")
    def run(self):
        self.f1()
        self.f2()

t=ThreadClass("xxxxx")
t.start()
t.join()